import time
from playsound import playsound

oct3 = ["keys/a2.mp3", "keys/a-2.mp3", 
		"keys/b2.mp3", "keys/c3.mp3", 
		"keys/c-3.mp3", "keys/d3.mp3", 
		"keys/d-3.mp3", "keys/e3.mp3", 
		"keys/f3.mp3", "keys/f-3.mp3", 
		"keys/g3.mp3", "keys/g-3.mp3"]

oct4 = ["keys/a3.mp3", "keys/a-3.mp3", 
		"keys/b3.mp3", "keys/c4.mp3", 
		"keys/c-4.mp3", "keys/d4.mp3", 
		"keys/d-4.mp3", "keys/e4.mp3", 
		"keys/f4.mp3", "keys/f-4.mp3", 
		"keys/g4.mp3", "keys/g-4.mp3"]

oct5 = ["keys/a4.mp3", "keys/a-4.mp3", 
		"keys/b4.mp3", "keys/c5.mp3", 
		"keys/c-5.mp3", "keys/d5.mp3", 
		"keys/d-5.mp3", "keys/e5.mp3", 
		"keys/f5.mp3", "keys/f-5.mp3", 
		"keys/g5.mp3", "keys/g-5.mp3"]

currentNote = ""

txtName = input("Enter the name of the text file you want to run (no need to put .txt at the end): ")
txtFile = open("txt/" + txtName + ".txt", "r")

for line in txtFile:
	for character in line:
		if character == "1":
			playsound(oct3[0])
			currentNote = "a2"
		elif character == "2":
			playsound(oct3[1])
			currentNote = "a#2"
		elif character == "z" or character == "Z":
			playsound(oct3[2])
			currentNote = "b2"
		elif character == "x" or character == "X":
			playsound(oct3[3])
			currentNote = "c3"
		elif character == "c" or character == "C":
			playsound(oct3[4])
			currentNote = "c#3"
		elif character == "v" or character == "V":
			playsound(oct3[5])
			currentNote = "d3"
		elif character == "b" or character == "B":
			playsound(oct3[6])
			currentNote = "d#3"
		elif character == "n" or character == "N":
			playsound(oct3[7])
			currentNote = "e3"
		elif character == "m" or character == "M":
			playsound(oct3[8])
			currentNote = "f3"
		elif character == ",":
			playsound(oct3[9])
			currentNote = "f#3"
		elif character == ".":
			playsound(oct3[10])
			currentNote = "g3"
		elif character == "/":
			playsound(oct3[11])
			currentNote = "g#3"

		elif character == "a" or character == "A":
			playsound(oct4[0])
			currentNote = "a3"
		elif character == "s" or character == "S":
			playsound(oct4[1])
			currentNote = "a#3"
		elif character == "d" or character == "D":
			playsound(oct4[2])
			currentNote = "b3"
		elif character == "f" or character == "F":
			playsound(oct4[3])
			currentNote = "c4"
		elif character == "g" or character == "G":
			playsound(oct4[4])
			currentNote = "c#4"
		elif character == "h" or character == "H":
			playsound(oct4[5])
			currentNote = "d4"
		elif character == "j" or character == "J":
			playsound(oct4[6])
			currentNote = "d#4"
		elif character == "k" or character == "K":
			playsound(oct4[7])
			currentNote = "e4"
		elif character == "l" or character == "L":
			playsound(oct4[8])
			currentNote = "f4"
		elif character == ";":
			playsound(oct4[9])
			currentNote = "f#4"
		elif character == "'":
			playsound(oct4[10])
			currentNote = "g4"
		elif character == "\\":
			playsound(oct4[11])
			currentNote = "g#4"

		elif character == "q" or character == "Q":
			playsound(oct5[0])
			currentNote = "a4"
		elif character == "w" or character == "W":
			playsound(oct5[1])
			currentNote = "a#4"
		elif character == "e" or character == "E":
			playsound(oct5[2])
			currentNote = "b4"
		elif character == "r" or character == "R":
			playsound(oct5[3])
			currentNote = "c5"
		elif character == "t" or character == "T":
			playsound(oct5[4])
			currentNote = "c#5"
		elif character == "y" or character == "Y":
			playsound(oct5[5])
			currentNote = "d5"
		elif character == "u" or character == "U":
			playsound(oct5[6])
			currentNote = "d#5"
		elif character == "i" or character == "I":
			playsound(oct5[7])
			currentNote = "e5"
		elif character == "o" or character == "O":
			playsound(oct5[8])
			currentNote = "f5"
		elif character == "p" or character == "P":
			playsound(oct5[9])
			currentNote = "f#5"
		elif character == "[":
			playsound(oct5[10])
			currentNote = "g5"
		elif character == "]":
			playsound(oct5[11])
			currentNote = "g#5"

		else:
			time.sleep(0.1)
			currentNote = "0.1 second rest"

		print(character + ": " + currentNote)
