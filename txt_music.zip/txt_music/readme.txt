All text files to be played go in the folder named "txt"

The note information can be found in notes.PNG

Python needs to be installed in order for this program to work because it's made with python.

To start the program, run txtmusic.bat or txtmusic.py.
txtmusic.py immediately closes the program after all the text in the file has been played
txtmusic.bat pauses after all the text in the file has been played, which is useful for reading errors

I like to run txtmusic.bat, but it's a matter of preference.